package com.example.apppokedex;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.List;
import java.net.URL;

public class FeedImageAdapter extends ArrayAdapter {
    private static final String TAG = "FeedAdapter";
    private final int layoutResource;
    private final LayoutInflater layoutInflater;
    private List<FeedEntry> applications;

    public FeedImageAdapter(@NonNull Context context, int resource, @NonNull List<FeedEntry> applications) {
        super(context, resource);
        this.layoutResource = resource;
        this.layoutInflater = LayoutInflater.from(context);
        this.applications = applications;
    }

    @Override
    public int getCount() {

        return applications.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null){
            convertView = layoutInflater.inflate(layoutResource, parent,  false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        FeedEntry currentApp = applications.get(position);

        viewHolder.tvName.setText(currentApp.getName());
        viewHolder.tvNumber.setText(currentApp.getNum());
        //viewHolder
        viewHolder.tvHeight.setText(currentApp.getHeight());
        viewHolder.tvWeiht.setText(currentApp.getWeight());

        try{
          //  viewHolder.tvType1.setText(currentApp.getType().get(0));
         //   viewHolder.tvType2.setText(currentApp.getType().get(1));
        }catch (IndexOutOfBoundsException e){
        }


        new DownloadImageTask(viewHolder.ivImageApp).execute(currentApp.getImgURL());
      /*
        Picasso.Builder builder = new Picasso.Builder(getContext());
        builder.downloader(new OkHttpDownloader(getContext()));
        builder.build().load(currentApp.getImgURL());
        .placeholder(R.drawable.list_records_images).into(viewHolder.ivImageApp);
        */
        return convertView;
    }

    private class ViewHolder{
        final TextView tvName;
        final TextView tvNumber;
        final ImageView ivImageApp;
        final TextView tvHeight;
        final TextView tvWeiht;
      //  final TextView tvType1;
      //  final TextView tvType2;


        ViewHolder(View v){
            this.tvName = v.findViewById(R.id.tvName);
            this.tvNumber = v.findViewById(R.id.tvNumber);
            this.tvHeight = v.findViewById(R.id.tvHeight);
            this.ivImageApp = v.findViewById(R.id.ivImageApp);
            this.tvWeiht = v.findViewById(R.id.tvWeight);
      //      this.tvType1 = v.findViewById(R.id.tvType1);
          //  this.tvType2 = v.findViewById(R.id.tvType2);
        }
    }
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

      public DownloadImageTask (ImageView bmImage){
          this.bmImage = bmImage;
      }

        @Override
        protected Bitmap doInBackground(String... urls) {
            String url = urls[0];
            url = url.replaceFirst("http://", "https://");

            Bitmap bmp = null;
            try{
                InputStream inputStream = new URL(url).openStream();
                bmp = BitmapFactory.decodeStream(inputStream);
            }catch(MalformedURLException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }

            return bmp;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            bmImage.setImageBitmap(bitmap);
        }

     }
}
