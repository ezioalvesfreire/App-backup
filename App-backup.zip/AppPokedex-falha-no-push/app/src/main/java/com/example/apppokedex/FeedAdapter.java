package com.example.apppokedex;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class FeedAdapter extends ArrayAdapter {
    private static final String TAG = "FeedAdapter";
    private final int layoutResource;
    private final LayoutInflater layoutInflater;
    private List<FeedEntry> applications;

    public FeedAdapter(@NonNull Context context, int resource, @NonNull List<FeedEntry> applications) {
        super(context, resource);
        this.layoutResource = resource;
        this.layoutInflater = LayoutInflater.from(context);
        this.applications = applications;
    }

    @Override
    public int getCount() {
        return applications.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null){
            convertView = layoutInflater.inflate(layoutResource, parent,  false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        FeedEntry currentApp = applications.get(position);

        viewHolder.tvNamexx.setText(currentApp.getName());
        viewHolder.tvNumberxx.setText(currentApp.getNum());
        viewHolder.ivImageAppxx.setText(currentApp.getImgURL());
        viewHolder.tvHeightxx.setText(currentApp.getHeight());
       // viewHolder.tvWeightxx.setText(currentApp.getWeight());
       //>>>> viewHolder.tvSummary.setText(currentApp.getWeiht()); reservado para o type

        return convertView;
    }

    private class ViewHolder{
        final TextView tvNamexx;
        final TextView tvNumberxx;
        final TextView ivImageAppxx;
        final TextView tvHeightxx;
        final TextView tvWeightxx;
       // final TextView tvType1xx; //reservado para Type
       // final TextView tvType2xx; //reservado para Type

        ViewHolder(View v){
            this.tvNamexx = v.findViewById(R.id.tvNamexx);
            this.tvNumberxx = v.findViewById(R.id.tvArtistxx);
            this.ivImageAppxx = v.findViewById(R.id.ivImageApp);
            this.tvHeightxx = v.findViewById(R.id.tvHeight);
            this.tvWeightxx = v.findViewById(R.id.tvWeight);
           // this.tvType1xx = v.findViewById(R.id.tvType1); // reservado para o type
          //  this.tvType2xx = v.findViewById(R.id.tvType1);
        }
    }

}
